package com.semagolet.artbook;

import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ArtAdapter extends RecyclerView.Adapter {

        public class  Artholder extends  RecyclerView.ViewHolder{

            public Artholder(@NonNull  View itemView) {
                super(itemView);
            }
        }

}
