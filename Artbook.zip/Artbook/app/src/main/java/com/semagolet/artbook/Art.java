package com.semagolet.artbook;

public class Art {
    String name;
    int id;

    public Art(String name, int id)
    {
        this.id=id;
        this.name=name;
    }

}
